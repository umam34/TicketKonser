<?php

namespace App\Http\Controllers;

use App\Models\Tiket;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        $tikets = Tiket::all();
        return view('admin.index', ['tikets' => $tikets]);
    }

    public function edit($id)
    {
        $tiket = Tiket::find($id);
        return view('admin.edit', ['tiket' => $tiket]);
    }

    public function update(Request $request, $id)
    {
        $tiket = Tiket::find($id);
        $tiket->nama_pengunjung = $request->input('nama_pengunjung');
        $tiket->email_pengunjung = $request->input('email_pengunjung');
        $tiket->save();

        return redirect('/admin')->with('success', 'Data pemesan berhasil diperbarui');
    }

    public function delete($id)
    {
        $tiket = Tiket::find($id);
        $tiket->delete();

        return redirect('/admin')->with('success', 'Data pemesan berhasil dihapus');
    }
}
