<?php

namespace App\Http\Controllers;

use App\Models\Tiket;
use Illuminate\Http\Request;

class CheckinController extends Controller
{
    public function index()
    {
        return view('check-in');
    }

    public function store(Request $request)
    {
        $nomorID = $request->input('nomor_id');
        $tiket = Tiket::where('nomor_id', $nomorID)->first();

        if ($tiket) {
            if ($tiket->status_checkin) {
                return redirect('/check-in')->with('error', 'Tiket sudah digunakan');
            }

            $tiket->status_checkin = true;
            $tiket->save();

            return view('biodata', ['tiket' => $tiket]);
        } else {
            return redirect('/check-in')->with('error', 'Tiket tidak valid');
        }
    }
}
