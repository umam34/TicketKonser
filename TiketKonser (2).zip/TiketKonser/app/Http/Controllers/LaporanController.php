<?php

namespace App\Http\Controllers;

use App\Models\Tiket;
use Illuminate\Http\Request;

class LaporanController extends Controller
{
    public function index()
    {
        $tiketsSudahCheckIn = Tiket::where('status_checkin', true)->get();
        $tiketsBelumCheckIn = Tiket::where('status_checkin', false)->get();

        return view('laporan', [
            'tiketsSudahCheckIn' => $tiketsSudahCheckIn,
            'tiketsBelumCheckIn' => $tiketsBelumCheckIn
        ]);
    }
}
