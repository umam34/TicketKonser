<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tiket;

class TiketController extends Controller
{
    public function index()
    {
        return view('tiket.index');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_pengunjung' => 'required',
            'email_pengunjung' => 'required|email',
            'jumlah_tiket' => 'required|numeric|min:1',
        ]);

        

    }


    public function create()
    {
        return view('pesan-tiket');
    }

 

    
}