<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
    <body>
        <h3>Tiket yang Sudah Check-in:</h3>
            @foreach($tiketsSudahCheckIn as $tiket)
                <p>{{ $tiket->nama_pengunjung }} - {{ $tiket->email_pengunjung }}</p>
            @endforeach

        <h3>Tiket yang Belum Check-in:</h3>
            @foreach($tiketsBelumCheckIn as $tiket)
                <p>{{ $tiket->nama_pengunjung }} - {{ $tiket->email_pengunjung }}</p>
            @endforeach
    </body>
</html>