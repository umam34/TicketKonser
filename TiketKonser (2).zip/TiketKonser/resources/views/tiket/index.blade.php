<!DOCTYPE html>
<html>
<head>
    <title>Pemesanan Tiket Konser</title>
</head>
<body>
    <h1>Pemesanan Tiket Konser</h1>

    @if(session('success'))
        <div style="color: green">{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('tiket.store') }}">
        @csrf

        <label for="nama_pengunjung">Nama Pengunjung:</label><br>
        <input type="text" id="nama_pengunjung" name="nama_pengunjung" required><br>

        <label for="email_pengunjung">Email Pengunjung:</label><br>
        <input type="email" id="email_pengunjung" name="email_pengunjung" required><br>

        <label for="jumlah_tiket">Jumlah Tiket:</label><br>
        <input type="number" id="jumlah_tiket" name="jumlah_tiket" required><br>

        <br>
        <button type="submit">Pesan Tiket</button>
    </form>
</body>
</html>
