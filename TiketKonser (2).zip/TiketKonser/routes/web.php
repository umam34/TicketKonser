<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TiketController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/', [TiketController::class, 'index'])->name('tiket.index');
Route::post('/tiket', [TiketController::class, 'store'])->name('tiket.store');
Route::get('/pesan-tiket', 'TiketController@create');
Route::post('/pesan-tiket', 'TiketController@store');

Route::middleware('auth')->group(function () {
    Route::get('/admin', 'AdminController@index');
    Route::get('/admin/edit/{id}', 'AdminController@edit');
    Route::post('/admin/update/{id}', 'AdminController@update');
    Route::delete('/admin/delete/{id}', 'AdminController@delete');
});

Route::middleware('auth')->group(function () {
    Route::get('/check-in', 'CheckInController@index');
    Route::post('/check-in', 'CheckInController@store');
});

Route::middleware('auth')->group(function () {
    Route::get('/laporan', 'LaporanController@index');
});